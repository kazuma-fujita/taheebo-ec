<?php
/*
 * Copyright(c) 2013 GMO Payment Gateway, Inc. All rights reserved.
 * http://www.gmo-pg.com/
 */

require_once(MDL_PG_MULPAY_CLASS_PATH . 'client/SC_Mdl_PG_MULPAY_Client_Sb.php');

/**
 * 決済モジュール 決済処理: Softbank
 */
class SC_Mdl_PG_MULPAY_Client_Sb_Ex extends SC_Mdl_PG_MULPAY_Client_Sb {
}
?>
